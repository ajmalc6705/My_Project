# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'TechbotErp Help Desk ',
    'version': '15.0.0.0.0',
    'description': 'Helpdesk Enterprise version15',
    'category': 'Services/Helpdesk',
    'author': 'TecbotERp',
    'website': "https://techboterp.com",
    'company': 'TechbotErp',
    'license': 'LGPL-3',
    'complexity': 'easy',
    'images': [],
    'sequence': -10,
    'summary': 'Adding background color for kanban view in helpdesk ticket',
    'depends': [
        'base',
        'helpdesk',
    ],
    'description': "",
    'data': [
        'views/helpdesk_ticket_add_color_kanban_view.xml',
        'views/helpdesk_ticket_views.xml',
        # 'views/helpdesk_stage_views.xml',

    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'assets': {
        'web.assets_backend': [
            'techboterp_helpdesk/static/src/scss/helpdesk.scss',
        ],
    },
}
