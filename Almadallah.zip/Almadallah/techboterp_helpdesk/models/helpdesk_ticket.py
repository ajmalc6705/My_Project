# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: TechbotErp(<https://techboterp.com/>)
#    you can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE , Version v1.0

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    GENERAL PUBLIC LICENSE (LGPL v3) along with this program.
#    If not, see <https://www.gnu.org/licenses/>.
#
##############################################################################

from odoo import models, fields, api
from datetime import datetime
from dateutil.relativedelta import relativedelta
from dateutil import relativedelta


class InheritHelpdeskTicket(models.Model):
    _inherit = "helpdesk.ticket"

    non_sla_dead_line = fields.Datetime("NON SLA Dead Line", compute='_compute_non_sla_deadline', store=True)
    time = fields.Float('In', help='Time to reach given stage based on ticket creation date', default=1, required=True)
    color = fields.Integer(string='Color Index', compute='_compute_color')
    ticket_overdue = fields.Boolean( compute='_compute_ticket_overdue_reminder', string='Ticket Overdue')

    @api.depends('time')
    def _compute_non_sla_deadline(self):
        for rec in self:
            rec.non_sla_dead_line = False
            rec.non_sla_dead_line = datetime.now() + relativedelta.relativedelta(hours=rec.time)

    @api.depends('stage_id', 'sla_deadline', 'non_sla_dead_line')
    def _compute_color(self):
        for ticket in self:
            ticket.color = 0
            if (ticket.sla_deadline and ticket.sla_deadline < fields.Datetime.now()) or (ticket.non_sla_dead_line and ticket.non_sla_dead_line < fields.Datetime.now()):
                """Background Color Changes Based on the Stages in Kanban View
                    if the deadline is overdue the background color is Red 
                    and the stage is closed then the background color red changed to white
                """
                if not ticket.stage_id.is_close:
                    ticket.color = 6
                else:
                    ticket.color = 0

    @api.depends('sla_deadline', 'non_sla_dead_line')
    def _compute_ticket_overdue_reminder(self):
        for record in self:
            overdue = False
            for ticket in record:
                if (ticket.non_sla_dead_line and ticket.non_sla_dead_line < fields.Datetime.now()) or (ticket.sla_deadline and ticket.sla_deadline < fields.Datetime.now()):
                    if not ticket.stage_id.is_close:
                        overdue = True
            record.ticket_overdue = overdue


"""
For Reference
@api.depends('ticket_id.create_date', 'sla_id', 'ticket_id.stage_id')
    def _compute_deadline(self):
        for status in self:
            if (status.deadline and status.reached_datetime) or (status.deadline and status.target_type == 'stage' and not status.sla_id.exclude_stage_ids) or (status.status == 'failed'):
                continue
            if status.target_type == 'assigning' and status.sla_stage_id == status.ticket_id.stage_id:
                deadline = fields.Datetime.now()
            elif status.target_type == 'assigning' and status.sla_stage_id:
                status.deadline = False
                continue
            else:
                deadline = status.ticket_id.create_date
            working_calendar = status.ticket_id.team_id.resource_calendar_id
            if not working_calendar:
                # Normally, having a working_calendar is mandatory
                status.deadline = deadline
                continue

            if status.target_type == 'stage' and status.sla_id.exclude_stage_ids:
                if status.ticket_id.stage_id in status.sla_id.exclude_stage_ids:
                    # We are in the freezed time stage: No deadline
                    status.deadline = False
                    continue

"""
