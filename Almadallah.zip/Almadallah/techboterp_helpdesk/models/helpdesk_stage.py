from odoo import models, fields, api

class InheritHelpdeskStage(models.Model):
    _inherit = "helpdesk.stage"
    # Currently, this model not Using and also Helpdesk stage view
    is_non_sla = fields.Boolean(string='Non SLA')

