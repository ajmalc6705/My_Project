{
    'name': 'TechbotErp User Avaiable in Help Desk',
    'version': '15.0.1.0.0',
    'summary': 'A module for Manage User Avaiable in Help Desk',
    'description': 'User Avaiable in Help Desk v15',
    'category': 'Helpdesk',
    'author': 'TecbotERp',
    'website': "https://techboterp.com",
    'company': 'TechbotErp',
    'license': 'LGPL-3',
    'complexity': 'easy',
    'sequence': '-100',
    'images': [],
    'depends': ['mail','helpdesk'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/user_available_wiz_view.xml',
        'views/techboterp_menu_views.xml',
        'views/user_view.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
    'assets': {
        'web.assets_backend': [
            'techboterp_user_available/static/src/js/kanban_header_btn.js',
        ],
    },
}
