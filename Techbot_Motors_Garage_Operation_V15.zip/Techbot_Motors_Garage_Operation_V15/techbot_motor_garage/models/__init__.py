# -*- coding: utf-8 -*-
from . import sale_order
from . import fleet
from . import res_partner


